const axios = require('./js/axios.min.js')

async function upload (filepath, clientId) {
  const data = new window.FormData()
  data.append('smfile', filepath)

  const response = await axios({
    method: 'post',
    url: 'https://sm.ms/api/upload',
    data
  })
  const result = Object.assign({ success: true, url: response.data.data.url })
  return result
}

var uploader = {
  upload: async function (files) {
    var results = []
    for (let i = 0; i < files.length; i++) {
      var f = files[i]
      try {
        var result = await upload(f)
        results.push({
          code: 'ok',
          url: result.url,
          message: 'ok',
          file: f.path
        })
      } catch (error) {
        results.push({
          code: 'warning',
          message: error.message,
          file: f.path
        })
      }
    }
    return results
  }
}

module.exports = uploader
