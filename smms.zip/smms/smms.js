var fs = require('fs');
var fetch = require('node-fetch');
var FormData = require('form-data');

async function upload(filepath, clientId) {
  var form = new FormData();
  form.append('smfile', fs.createReadStream(filepath.path));

  const response = await fetch('https://sm.ms/api/upload', {
    method: 'POST',
    body: form,
  });
  const res = await response.json();
  const result = Object.assign({
    success: true,
    url: res.data.url,
  });
  return result;
}

var uploader = {
  upload: async function(files) {
    var results = [];
    for (let i = 0; i < files.length; i++) {
      var f = files[i];
      try {
        var result = await upload(f);
        results.push({
          code: 'ok',
          url: result.url,
          message: 'ok',
          file: f.path,
        });
      } catch (error) {
        results.push({
          code: 'warning',
          message: error.message,
          file: f.path,
        });
      }
    }
    return results;
  },
};

module.exports = uploader;
