var fse = require('fs-extra')
var path = require('path')
var relative = require('relative')
const normalize = require('normalize-path')

var uploader = {
  upload: async function(files, option) {
    if (option && option.token) {
    }
    var d = new Date()
    var local = path.join(
      '.local',
      'static',
      d.getFullYear() + '',
      d.getMonth() + '',
      d.getDay() + ''
    )
    var fullpath = path.join(option.workpath, local)
    if (!fse.pathExistsSync(fullpath)) {
      fse.mkdirpSync(fullpath)
    }
    var results = []
    for (let i = 0; i < files.length; i++) {
      var f = files[i].path
      var filename = path.basename(f)
      var ext = path.extname(filename)
      var name = filename
        .split('.')
        .slice(0, -1)
        .join('.')
      var time = new Date().getTime() + ''
      var target = path.join(fullpath, name + '.' + time + ext)
      fse.copyFileSync(f, target)
      var url = relative(option.editfile, target)
      url = normalize(url)
      try {
        results.push({
          code: 'ok',
          url: url,
          message: 'ok',
          file: files[i]
        })
      } catch (error) {
        results.push({
          code: 'warning',
          message: error.message,
          file: f
        })
      }
    }
    return results
  }
}

module.exports = uploader
