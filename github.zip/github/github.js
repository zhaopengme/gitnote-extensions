const fs = require('fs')
const path = require('path')
const axios = require('axios')

Date.prototype.Format = function(fmt) {
  //author: meizz
  var o = {
    'M+': this.getMonth() + 1, //月份
    'd+': this.getDate(), //日
    'h+': this.getHours(), //小时
    'm+': this.getMinutes(), //分
    's+': this.getSeconds(), //秒
    'q+': Math.floor((this.getMonth() + 3) / 3), //季度
    S: this.getMilliseconds() //毫秒
  }
  if (/(y+)/.test(fmt))
    fmt = fmt.replace(
      RegExp.$1,
      (this.getFullYear() + '').substr(4 - RegExp.$1.length)
    )
  for (var k in o)
    if (new RegExp('(' + k + ')').test(fmt))
      fmt = fmt.replace(
        RegExp.$1,
        RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
      )
  return fmt
}

function base64_encode(file) {
  var bitmap = fs.readFileSync(file)
  return Buffer.from(bitmap).toString('base64')
}

async function upload(fileName, option, data) {
  const name = path
    .basename(fileName)
    .split('.')
    .slice(0, -1)
    .join('.')
  const ext = path.extname(fileName)
  const date = new Date().Format('yyyy/MM/dd')
  const url = `https://api.github.com/repos/${option.repo}/contents/${encodeURI(
    option.bucket
  )}/${date}/${encodeURI(name + '-' + new Date().getTime() + ext)}`

  const config = {
    headers: {
      Accept: 'application/vnd.github.v3.raw+json',
      Authorization: `token ${option.token}`
    }
  }
  const response = await axios.put(url, data, config)
  const result = Object.assign({
    success: true,
    url: response.data.content.download_url
  })
  return result
}

var uploader = {
  upload: async function(files, option) {
    var results = []
    for (let i = 0; i < files.length; i++) {
      var f = files[i].path
      try {
        var base64 = base64_encode(f)
        const data = { message: 'from Github For GitNote', content: base64 }
        var result = await upload(path.basename(f), option, data)
        results.push({
          code: 'ok',
          url: result.url,
          message: 'ok',
          file: f.path
        })
      } catch (error) {
        results.push({
          code: 'warning',
          message: error.message,
          file: f.path
        })
      }
    }
    return results
  }
}

module.exports = uploader
