$(function() {
  $('#file-input')
    .off('change')
    .on('change', function() {
      var file = $(this)[0].files[0]
      var fileType = file.name.substr(file.name.lastIndexOf('.') + 1)
      switch (fileType) {
        case 'xml':
          fileType = 'xml'
          break
        case 'txt':
          fileType = 'txt'
          break
        case 'mxe':
          fileType = 'mxe'
          break
        default:
          console.log('File not supported!')
          alert('只支持.xml、.txt、.mxe文件')
          return
      }
      var reader = new FileReader()
      reader.onload = function(e) {
        try {
          var content = reader.result
          var doc = mxUtils.parseXml(content)
          window.editorUi.editor.setGraphXml(doc.documentElement)
          window.editorUi.editor.setModified(false)
          window.editorUi.editor.undoManager.clear()

          if (file.name != null) {
            window.editorUi.editor.setFilename(file.name)
            window.editorUi.updateDocumentTitle()
          }
        } catch (e) {
          mxUtils.alert(
            mxResources.get('invalidOrMissingFile') + ': ' + e.message
          )
        }
      }
      reader.readAsText(file)
    })

  if (!gutil.isBlank(gutil.query)) {
    var query = JSON.parse(decodeURIComponent(gutil.query))
    var n = localStorage.getItem('new')
    if (n == 'new') {
      localStorage.removeItem('new')
      return
    }
    if (!gutil.isBlank(query.path)) {
      try {
        var content = gutil.readFile(query.path)
        var doc = mxUtils.parseXml(content)
        window.editorUi.editor.setGraphXml(doc.documentElement)
        window.editorUi.editor.setModified(false)
        window.editorUi.editor.undoManager.clear()

        if (gutil.query != null) {
          window.editorUi.editor.setFilename(query.path)
          window.editorUi.updateDocumentTitle()
        }
      } catch (e) {
        mxUtils.alert(
          mxResources.get('invalidOrMissingFile') + ': ' + e.message
        )
      }
    }
  }
})
