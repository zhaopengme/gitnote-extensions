var fs = require('fs');
var fetch = require('node-fetch');
var FormData = require('form-data');

async function upload(filepath, clientId) {
  var form = new FormData();
  form.append('image', fs.createReadStream(filepath.path));
  form.append('type', 'file');

  const response = await fetch('https://api.imgur.com/3/image', {
    method: 'POST',
    body: form,
    headers: { authorization: 'Client-ID ' + clientId },
  });

  const res = await response.json();
  const result = Object.assign({
    success: true,
    url: res.data.link,
  });
  return result;
}

var uploader = {
  upload: async function(files, option) {
    let token = 'b7f2b620ed31f19';
    if (option && option.token) {
      token = option.token;
    }
    var results = [];
    for (let i = 0; i < files.length; i++) {
      var f = files[i];
      try {
        var result = await upload(f, token);
        results.push({
          code: 'ok',
          url: result.url,
          message: 'ok',
          file: f.path,
        });
      } catch (error) {
        results.push({
          code: 'warning',
          message: error.message,
          file: f.path,
        });
      }
    }
    return results;
  },
};

module.exports = uploader;
