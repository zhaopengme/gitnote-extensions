const axios = require('./js/axios.min.js')

async function upload(filepath, clientId) {
  const data = new window.FormData()
  data.append('image', filepath)
  data.append('type', 'file')

  const response = await axios({
    method: 'post',
    url: 'https://api.imgur.com/3/image',
    data,
    headers: {
      authorization: 'Client-ID ' + clientId
    }
  })
  const result = Object.assign({
    success: true,
    url: response.data.data.link
  })
  return result
}

var uploader = {
  upload: async function(files, option) {
    let token = 'b7f2b620ed31f19'
    if (option && option.token) {
      token = option.token
    }
    var results = []
    for (let i = 0; i < files.length; i++) {
      var f = files[i]
      try {
        var result = await upload(f, token)
        results.push({
          code: 'ok',
          url: result.url,
          message: 'ok',
          file: f.path
        })
      } catch (error) {
        results.push({
          code: 'warning',
          message: error.message,
          file: f.path
        })
      }
    }
    return results
  }
}

module.exports = uploader
