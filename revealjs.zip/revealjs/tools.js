var fs = require('fs')
var path = require('path')
const homedir = require('os').homedir()

var waitForGlobal = function(key, callback) {
  if (window[key]) {
    callback()
  } else {
    setTimeout(function() {
      waitForGlobal(key, callback)
    }, 100)
  }
}
function append(elString, parent) {
  var div = document.createElement('div')
  div.innerHTML = elString
  document.querySelector(parent || 'body').appendChild(div.firstChild)
}

function mkdir(dir) {
  // making directory without exception if exists
  try {
    fs.mkdirSync(dir, 0755)
  } catch (e) {
    if (e.code != 'EEXIST') {
      throw e
    }
  }
}

function copy(src, dest) {
  var oldFile = fs.createReadStream(src)
  var newFile = fs.createWriteStream(dest)
  oldFile.pipe(newFile)
}

function copyDir(src, dest) {
  mkdir(dest)
  var files = fs.readdirSync(src)
  for (var i = 0; i < files.length; i++) {
    var current = fs.lstatSync(path.join(src, files[i]))
    if (current.isDirectory()) {
      copyDir(path.join(src, files[i]), path.join(dest, files[i]))
    } else if (current.isSymbolicLink()) {
      var symlink = fs.readlinkSync(path.join(src, files[i]))
      fs.symlinkSync(symlink, path.join(dest, files[i]))
    } else {
      copy(path.join(src, files[i]), path.join(dest, files[i]))
    }
  }
}

function isURL(str) {
  var strRegex = '^((https|http)?://)'
  var re = new RegExp(strRegex)
  return re.test(str)
}

function base64_encode(file) {
  if (fs.existsSync(file)) {
    var extname = path.extname(file).substr(1)
    extname = extname || 'png'
    if (extname === 'svg') {
      extname = 'svg+xml'
    }
    var bitmap = fs.readFileSync(file)
    return (
      'data:image/' +
      extname +
      ';base64,' +
      Buffer.from(bitmap).toString('base64')
    )
  }
  return null
}

waitForGlobal('mdfile', function() {
  var content = fs.readFileSync(window.mdfile, 'utf-8')
  content = content.replace(/!\[([\s\S]*?)\]\(([\s\S]*?[^\\])\)/g, function(
    m,
    alt,
    src
  ) {
    if (src && !isURL(src)) {
      var source = fs.existsSync(src)
        ? src
        : fs.existsSync(path.join(workpath, src))
        ? path.join(workpath, src)
        : fs.existsSync(path.join(path.dirname(mdfile), src))
        ? path.join(path.dirname(mdfile), src)
        : null
      if (source) {
        var base64 = base64_encode(source)
        return `<img src="${base64}" alt="${alt}">`
      }
    }
    return m
  })
  document.getElementById('md-tpl').innerHTML = content

  // append('<section data-markdown="' + window.mdfile + '"></section>', '.slides')

  var exportBtn = document.getElementById('export-btn')
  exportBtn.addEventListener('click', function(e) {
    e.stopImmediatePropagation()
    try {
      var revealDir = path.join(homedir, 'reveal')
      if (!fs.existsSync(revealDir)) {
        fs.mkdirSync(revealDir)
      }
      var target = path.join(revealDir, new Date().getTime() + '')
      fs.mkdirSync(target)
      var pwd = path.join(homedir, '.gitnote', 'plugins', 'revealjs')
      var dirs = ['css', 'js', 'lib', 'plugin']
      for (let i = 0; i < dirs.length; i++) {
        var dir = dirs[i]
        var sourceDir = path.join(pwd, dir)
        var targetDir = path.join(target, dir)
        copyDir(sourceDir, targetDir)
      }
      var tplFile = path.join(pwd, 'index.template')
      var tpl = fs.readFileSync(tplFile, 'utf-8')
      tpl = tpl.replace('{{content}}', content)
      tpl = tpl.replace('{{title}}', 'made by gitnote')
      var targetIdx = path.join(target, 'index.html')
      fs.writeFileSync(targetIdx, tpl, 'utf-8')
      alert('Generate successfully. File save on ' + target)
    } catch (error) {
      alert('Generate Error.Error Message ' + error.message)
    }
  })

  // More info https://github.com/hakimel/reveal.js#configuration
  Reveal.initialize({
    controls: true,
    progress: true,
    history: true,
    center: true,

    transition: 'slide', // none/fade/slide/convex/concave/zoom

    // More info https://github.com/hakimel/reveal.js#dependencies
    dependencies: [
      {
        src: 'lib/js/classList.js',
        condition: function() {
          return !document.body.classList
        }
      },
      {
        src: 'plugin/markdown/marked.js',
        condition: function() {
          return !!document.querySelector('[data-markdown]')
        }
      },
      {
        src: 'plugin/markdown/markdown.js',
        condition: function() {
          return !!document.querySelector('[data-markdown]')
        }
      },
      {
        src: 'plugin/highlight/highlight.js',
        async: true,
        callback: function() {
          hljs.initHighlightingOnLoad()
        }
      },
      { src: 'plugin/search/search.js', async: true },
      { src: 'plugin/zoom-js/zoom.js', async: true },
      { src: 'plugin/notes/notes.js', async: true }
    ]
  })
})
